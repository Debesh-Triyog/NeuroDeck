import { Pressable, Text, type PressableProps, type ViewStyle } from "react-native";
import { cn } from "@/lib/utils";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

export interface PremiumButtonProps extends PressableProps {
  /**
   * Button label text.
   */
  label: string;
  /**
   * Button variant: "primary" (neon blue), "secondary" (outline), or "ghost" (transparent).
   */
  variant?: "primary" | "secondary" | "ghost";
  /**
   * Button size: "sm", "md", or "lg".
   */
  size?: "sm" | "md" | "lg";
  /**
   * Whether the button is disabled.
   */
  disabled?: boolean;
  /**
   * Whether to show a loading state.
   */
  loading?: boolean;
  /**
   * Tailwind className for the button container.
   */
  className?: string;
  /**
   * Tailwind className for the label text.
   */
  labelClassName?: string;
}

/**
 * A premium button component with haptic feedback and smooth animations.
 * Features neon blue accents, multiple variants, and loading states.
 *
 * Usage:
 * ```tsx
 * <PremiumButton
 *   label="Get Started"
 *   variant="primary"
 *   onPress={() => handlePress()}
 * />
 * ```
 */
export function PremiumButton({
  label,
  variant = "primary",
  size = "md",
  disabled = false,
  loading = false,
  className,
  labelClassName,
  onPress,
  ...props
}: PremiumButtonProps) {
  const handlePress = (e: any) => {
    if (!disabled && !loading && onPress) {
      // Trigger haptic feedback
      if (Platform.OS !== "web") {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
      }
      onPress(e);
    }
  };

  const sizeStyles: Record<string, string> = {
    sm: "px-4 py-2",
    md: "px-6 py-3",
    lg: "px-8 py-4",
  };

  const variantStyles: Record<string, string> = {
    primary: "bg-gradient-accent border-0",
    secondary: "bg-transparent border border-primary",
    ghost: "bg-transparent border-0",
  };

  const labelColorStyles: Record<string, string> = {
    primary: "text-background font-semibold",
    secondary: "text-primary font-semibold",
    ghost: "text-foreground font-semibold",
  };

  return (
    <Pressable
      onPress={handlePress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        {
          transform: pressed && !disabled && !loading ? [{ scale: 0.97 }] : [{ scale: 1 }],
          opacity: disabled || loading ? 0.5 : pressed ? 0.85 : 1,
        } as ViewStyle,
      ]}
      {...props}
    >
      <Text
        className={cn(
          "rounded-sm text-center",
          sizeStyles[size],
          variantStyles[variant],
          labelColorStyles[variant],
          className
        )}
      >
        {loading ? "Loading..." : label}
      </Text>
    </Pressable>
  );
}
