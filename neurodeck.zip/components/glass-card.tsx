import { View, type ViewProps } from "react-native";
import { cn } from "@/lib/utils";

export interface GlassCardProps extends ViewProps {
  /**
   * Tailwind className for the card content.
   */
  className?: string;
  /**
   * Whether to use a more opaque glass effect.
   */
  opaque?: boolean;
}

/**
 * A premium glassmorphic card component with frosted glass effect.
 * Features blur, transparency, and soft shadows.
 *
 * Usage:
 * ```tsx
 * <GlassCard className="p-4">
 *   <Text className="text-lg font-semibold text-foreground">
 *     Premium Card
 *   </Text>
 * </GlassCard>
 * ```
 */
export function GlassCard({
  children,
  className,
  opaque = false,
  style,
  ...props
}: GlassCardProps) {
  return (
    <View
      className={cn(
        "rounded-md border",
        opaque
          ? "bg-surface/80 dark:bg-surface/60 border-border/50"
          : "bg-white/10 dark:bg-white/5 border-white/20 dark:border-white/10",
        className
      )}
      style={[
        {
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 8 },
          shadowOpacity: 0.1,
          shadowRadius: 16,
          elevation: 4,
        },
        style,
      ]}
      {...props}
    >
      {children}
    </View>
  );
}
