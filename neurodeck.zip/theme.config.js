/** @type {const} */
const themeColors = {
  // Primary neon blue accent (consistent across themes)
  primary: { light: '#00D9FF', dark: '#00D9FF' },
  // Deep blue secondary accent
  accent: { light: '#0066FF', dark: '#0066FF' },
  // Background colors
  background: { light: '#FFFFFF', dark: '#0F1419' },
  // Surface/card colors with glassmorphism
  surface: { light: '#F5F7FA', dark: '#1A1F2E' },
  // Text colors
  foreground: { light: '#0F1419', dark: '#F3F4F6' },
  muted: { light: '#6B7280', dark: '#9CA3AF' },
  // Border colors
  border: { light: '#E5E7EB', dark: '#334155' },
  // Status colors
  success: { light: '#10B981', dark: '#34D399' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
  // Gradient base colors
  gradientStart: { light: '#001F3F', dark: '#001F3F' },
  gradientEnd: { light: '#0F1419', dark: '#1A1F2E' },
};

module.exports = { themeColors };
