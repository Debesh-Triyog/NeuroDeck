const { themeColors } = require("./theme.config");
const plugin = require("tailwindcss/plugin");

const tailwindColors = Object.fromEntries(
  Object.entries(themeColors).map(([name, swatch]) => [
    name,
    {
      DEFAULT: `var(--color-${name})`,
      light: swatch.light,
      dark: swatch.dark,
    },
  ]),
);

/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: ["./app/**/*.{js,ts,tsx}", "./components/**/*.{js,ts,tsx}", "./lib/**/*.{js,ts,tsx}", "./hooks/**/*.{js,ts,tsx}"],

  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: tailwindColors,
      borderRadius: {
        xs: "8px",
        sm: "12px",
        md: "16px",
        lg: "20px",
      },
      spacing: {
        xs: "4px",
        sm: "8px",
        md: "12px",
        lg: "16px",
        xl: "24px",
        "2xl": "32px",
      },
      fontSize: {
        xs: ["12px", { lineHeight: "16px" }],
        sm: ["14px", { lineHeight: "20px" }],
        base: ["16px", { lineHeight: "24px" }],
        lg: ["18px", { lineHeight: "28px" }],
        xl: ["20px", { lineHeight: "28px" }],
        "2xl": ["24px", { lineHeight: "32px" }],
        "3xl": ["32px", { lineHeight: "40px" }],
        "4xl": ["40px", { lineHeight: "48px" }],
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      opacity: {
        glass: "0.8",
      },
      backdropBlur: {
        glass: "10px",
      },
    },
  },
  plugins: [
    plugin(({ addVariant, addUtilities, theme }) => {
      addVariant("light", ':root:not([data-theme="dark"]) &');
      addVariant("dark", ':root[data-theme="dark"] &');

      addUtilities({
        ".glass": {
          "@apply bg-white/10 dark:bg-white/5 backdrop-blur-glass border border-white/20 dark:border-white/10": {},
        },
        ".glass-card": {
          "@apply glass rounded-md shadow-lg": {},
        },
        ".gradient-primary": {
          backgroundImage: "linear-gradient(135deg, #001F3F 0%, #0F1419 50%, #1A1F2E 100%)",
        },
        ".gradient-accent": {
          backgroundImage: "linear-gradient(135deg, #00D9FF 0%, #0066FF 100%)",
        },
      });
    }),
  ],
};
