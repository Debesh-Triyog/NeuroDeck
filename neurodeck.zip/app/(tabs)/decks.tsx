import { ScrollView, Text, View, Pressable, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { GlassCard } from "@/components/glass-card";
import { PremiumButton } from "@/components/premium-button";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

interface Deck {
  id: string;
  name: string;
  subject: string;
  cardCount: number;
  masteredCount: number;
  lastStudied: string;
}

/**
 * Decks Screen - Manage and browse study decks
 *
 * Features:
 * - View all decks with stats
 * - Create new deck
 * - Quick actions (Study, Quiz, Delete)
 * - Mastery percentage display
 */
export default function DecksScreen() {
  const colors = useColors();

  const decks: Deck[] = [
    {
      id: "1",
      name: "Biology 101",
      subject: "Science",
      cardCount: 45,
      masteredCount: 39,
      lastStudied: "Today",
    },
    {
      id: "2",
      name: "Spanish Vocab",
      subject: "Languages",
      cardCount: 120,
      masteredCount: 74,
      lastStudied: "Yesterday",
    },
    {
      id: "3",
      name: "Math Formulas",
      subject: "Mathematics",
      cardCount: 78,
      masteredCount: 71,
      lastStudied: "2 days ago",
    },
    {
      id: "4",
      name: "History Dates",
      subject: "History",
      cardCount: 92,
      masteredCount: 45,
      lastStudied: "1 week ago",
    },
  ];

  const renderDeckCard = ({ item }: { item: Deck }) => {
    const masteryPercentage = Math.round((item.masteredCount / item.cardCount) * 100);

    return (
      <GlassCard className="p-4 mb-3">
        <View className="flex-row items-start justify-between mb-3">
          <View className="flex-1">
            <Text className="text-lg font-semibold text-foreground">{item.name}</Text>
            <Text className="text-xs text-muted mt-1">{item.subject}</Text>
          </View>
          <View className="bg-primary/20 dark:bg-primary/10 px-3 py-1 rounded-full">
            <Text className="text-sm font-bold text-primary">{masteryPercentage}%</Text>
          </View>
        </View>

        {/* Progress Bar */}
        <View className="h-2 bg-surface rounded-full overflow-hidden mb-3">
          <View
            className="h-full bg-gradient-accent"
            style={{ width: `${masteryPercentage}%` }}
          />
        </View>

        {/* Stats */}
        <View className="flex-row justify-between mb-3">
          <Text className="text-xs text-muted">
            {item.masteredCount} / {item.cardCount} cards
          </Text>
          <Text className="text-xs text-muted">Last: {item.lastStudied}</Text>
        </View>

        {/* Action Buttons */}
        <View className="flex-row gap-2">
          <Pressable
            className="flex-1 bg-primary/20 dark:bg-primary/10 py-2 rounded-md items-center"
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <Text className="text-sm font-semibold text-primary">Study</Text>
          </Pressable>
          <Pressable
            className="flex-1 bg-accent/20 dark:bg-accent/10 py-2 rounded-md items-center"
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <Text className="text-sm font-semibold text-accent">Quiz</Text>
          </Pressable>
          <Pressable
            className="flex-1 bg-error/20 dark:bg-error/10 py-2 rounded-md items-center"
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          >
            <Text className="text-sm font-semibold text-error">Delete</Text>
          </Pressable>
        </View>
      </GlassCard>
    );
  };

  return (
    <ScreenContainer className="flex-1 bg-background">
      <View className="flex-row items-center justify-between px-4 py-4">
        <Text className="text-2xl font-bold text-foreground">My Decks</Text>
        <Pressable
          className="bg-primary p-2 rounded-full"
          style={({ pressed }) => [{ opacity: pressed ? 0.8 : 1 }]}
        >
          <IconSymbol name="plus.circle.fill" size={24} color={colors.background} />
        </Pressable>
      </View>

      <FlatList
        data={decks}
        renderItem={renderDeckCard}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24 }}
        scrollEnabled={false}
        ListFooterComponent={
          <View className="mt-4">
            <PremiumButton
              label="Create New Deck"
              variant="secondary"
              size="lg"
              onPress={() => console.log("Create Deck")}
            />
          </View>
        }
      />
    </ScreenContainer>
  );
}
