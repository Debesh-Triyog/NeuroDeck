import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { GlassCard } from "@/components/glass-card";
import { PremiumButton } from "@/components/premium-button";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useTheme } from "@/lib/theme-context";

interface ProfileStat {
  label: string;
  value: string;
  icon: string;
}

/**
 * Profile Screen - User profile, stats, and settings
 *
 * Features:
 * - User profile with avatar and rank badge
 * - Comprehensive stats grid
 * - Settings and preferences
 * - Achievements and badges
 */
export default function ProfileScreen() {
  const colors = useColors();
  const { colorScheme, toggleTheme } = useTheme();

  const userProfile = {
    name: "Casey Brown",
    rank: "🥉 Bronze",
    xp: 12540,
    level: 8,
    avatar: "👤",
  };

  const stats: ProfileStat[] = [
    { label: "Study Hours", value: "24h", icon: "⏱️" },
    { label: "Cards Mastered", value: "187", icon: "✓" },
    { label: "Accuracy", value: "87%", icon: "🎯" },
    { label: "Current Streak", value: "28d", icon: "🔥" },
    { label: "Decks Created", value: "12", icon: "📚" },
    { label: "Achievements", value: "8", icon: "🏆" },
  ];

  const settingsItems = [
    { label: "Notifications", icon: "bell.fill", value: "On" },
    { label: "Dark Mode", icon: colorScheme === "dark" ? "moon.fill" : "sun.max.fill", value: colorScheme },
    { label: "Privacy", icon: "lock.fill", value: "Public" },
    { label: "About", icon: "info.circle.fill", value: "" },
  ];

  return (
    <ScreenContainer className="flex-1 bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View className="items-center py-6 px-4">
          <View className="w-20 h-20 rounded-full bg-primary/20 dark:bg-primary/10 items-center justify-center mb-4">
            <Text className="text-5xl">{userProfile.avatar}</Text>
          </View>
          <Text className="text-2xl font-bold text-foreground">{userProfile.name}</Text>
          <Text className="text-lg text-primary font-semibold mt-1">{userProfile.rank}</Text>
          <Text className="text-sm text-muted mt-2">Level {userProfile.level}</Text>
        </View>

        {/* XP Progress */}
        <View className="px-4 pb-4">
          <GlassCard className="p-4">
            <View className="flex-row justify-between mb-2">
              <Text className="text-sm font-semibold text-foreground">Total XP</Text>
              <Text className="text-sm font-bold text-primary">{userProfile.xp.toLocaleString()}</Text>
            </View>
            <View className="h-3 bg-surface rounded-full overflow-hidden">
              <View className="h-full bg-gradient-accent" style={{ width: "68%" }} />
            </View>
            <Text className="text-xs text-muted mt-2">4,120 XP to next level</Text>
          </GlassCard>
        </View>

        {/* Stats Grid */}
        <View className="px-4 pb-4">
          <Text className="text-lg font-semibold text-foreground mb-3">Statistics</Text>
          <View className="gap-2">
            {stats.map((stat, index) => (
              <GlassCard key={index} className="p-4 flex-row items-center justify-between">
                <View className="flex-row items-center gap-3 flex-1">
                  <Text className="text-2xl">{stat.icon}</Text>
                  <Text className="text-sm text-muted">{stat.label}</Text>
                </View>
                <Text className="text-lg font-bold text-primary">{stat.value}</Text>
              </GlassCard>
            ))}
          </View>
        </View>

        {/* Settings Section */}
        <View className="px-4 pb-4">
          <Text className="text-lg font-semibold text-foreground mb-3">Settings</Text>
          <View className="gap-2">
            {settingsItems.map((item, index) => (
              <Pressable
                key={index}
                className="p-0"
                onPress={item.label === "Dark Mode" ? toggleTheme : () => console.log(item.label)}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <GlassCard className="p-4 flex-row items-center justify-between">
                  <View className="flex-row items-center gap-3 flex-1">
                    <IconSymbol
                      name={item.icon as any}
                      size={20}
                      color={colors.primary}
                    />
                    <Text className="text-base text-foreground font-medium">{item.label}</Text>
                  </View>
                  <Text className="text-sm text-muted">{item.value}</Text>
                </GlassCard>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Achievements */}
        <View className="px-4 pb-4">
          <Text className="text-lg font-semibold text-foreground mb-3">Recent Achievements</Text>
          <View className="flex-row gap-2 flex-wrap">
            {["🎯", "🔥", "🏆", "⭐", "🌟", "💎"].map((badge, index) => (
              <GlassCard key={index} className="w-14 h-14 items-center justify-center">
                <Text className="text-2xl">{badge}</Text>
              </GlassCard>
            ))}
          </View>
        </View>

        {/* Logout Button */}
        <View className="px-4 pb-8">
          <PremiumButton
            label="Logout"
            variant="secondary"
            size="lg"
            onPress={() => console.log("Logout")}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
