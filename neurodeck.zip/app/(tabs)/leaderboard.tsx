import { ScrollView, Text, View, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { GlassCard } from "@/components/glass-card";
import { useColors } from "@/hooks/use-colors";

interface LeaderboardEntry {
  rank: number;
  name: string;
  xp: number;
  streak: number;
  badge: string;
}

/**
 * Leaderboard Screen - Competitive rankings and user stats
 *
 * Features:
 * - Global leaderboard with top users
 * - Rank badges (Bronze, Silver, Gold, etc.)
 * - User stats and XP tracking
 * - Weekly/monthly/all-time filters
 */
export default function LeaderboardScreen() {
  const colors = useColors();

  const leaderboardData: LeaderboardEntry[] = [
    { rank: 1, name: "Alex Chen", xp: 15420, streak: 45, badge: "🏆 Grand Scholar" },
    { rank: 2, name: "Jordan Smith", xp: 14850, streak: 38, badge: "🥇 Gold" },
    { rank: 3, name: "Sam Wilson", xp: 13920, streak: 35, badge: "🥈 Silver" },
    { rank: 4, name: "Casey Brown", xp: 12540, streak: 28, badge: "🥉 Bronze" },
    { rank: 5, name: "Morgan Lee", xp: 11890, streak: 25, badge: "🌟 Achiever" },
    { rank: 6, name: "Taylor Davis", xp: 10750, streak: 22, badge: "🌟 Achiever" },
    { rank: 7, name: "Riley Martinez", xp: 9820, streak: 18, badge: "📚 Scholar" },
    { rank: 8, name: "Jamie Johnson", xp: 8950, streak: 15, badge: "📚 Scholar" },
    { rank: 9, name: "Blake Anderson", xp: 7680, streak: 12, badge: "🎯 Learner" },
    { rank: 10, name: "Avery Taylor", xp: 6540, streak: 8, badge: "🎯 Learner" },
  ];

  const currentUserRank = 4;
  const currentUser = leaderboardData[currentUserRank - 1];

  const renderLeaderboardItem = ({ item }: { item: LeaderboardEntry }) => {
    const isCurrentUser = item.rank === currentUserRank;
    return (
      <GlassCard
        className={`p-4 mb-2 flex-row items-center justify-between ${
          isCurrentUser ? "bg-primary/10 dark:bg-primary/5" : ""
        }`}
      >
        <View className="flex-row items-center flex-1 gap-3">
          <View className="w-8 h-8 rounded-full bg-primary/20 dark:bg-primary/10 items-center justify-center">
            <Text className="font-bold text-primary text-sm">{item.rank}</Text>
          </View>
          <View className="flex-1">
            <Text className="text-base font-semibold text-foreground">{item.name}</Text>
            <Text className="text-xs text-muted mt-1">{item.badge}</Text>
          </View>
        </View>
        <View className="items-end gap-1">
          <Text className="text-base font-bold text-primary">{item.xp.toLocaleString()} XP</Text>
          <Text className="text-xs text-muted">🔥 {item.streak} day</Text>
        </View>
      </GlassCard>
    );
  };

  return (
    <ScreenContainer className="flex-1 bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-4 py-4">
          <Text className="text-2xl font-bold text-foreground">Leaderboard</Text>
        </View>

        {/* Current User Card */}
        <View className="px-4 pb-4">
          <GlassCard className="p-6 bg-gradient-accent/10 dark:bg-gradient-accent/5">
            <View className="items-center mb-4">
              <View className="w-16 h-16 rounded-full bg-primary/20 dark:bg-primary/10 items-center justify-center mb-3">
                <Text className="text-3xl">👤</Text>
              </View>
              <Text className="text-lg font-semibold text-foreground">You</Text>
              <Text className="text-sm text-primary font-semibold mt-1">{currentUser.badge}</Text>
            </View>

            <View className="flex-row justify-around">
              <View className="items-center">
                <Text className="text-2xl font-bold text-primary">#{currentUser.rank}</Text>
                <Text className="text-xs text-muted mt-1">Rank</Text>
              </View>
              <View className="items-center">
                <Text className="text-2xl font-bold text-primary">{currentUser.xp.toLocaleString()}</Text>
                <Text className="text-xs text-muted mt-1">XP</Text>
              </View>
              <View className="items-center">
                <Text className="text-2xl font-bold text-primary">🔥{currentUser.streak}</Text>
                <Text className="text-xs text-muted mt-1">Streak</Text>
              </View>
            </View>
          </GlassCard>
        </View>

        {/* Time Filter */}
        <View className="px-4 pb-4 flex-row gap-2">
          <GlassCard className="flex-1 py-2 items-center bg-primary/20 dark:bg-primary/10">
            <Text className="text-sm font-semibold text-primary">Weekly</Text>
          </GlassCard>
          <GlassCard className="flex-1 py-2 items-center">
            <Text className="text-sm font-semibold text-muted">Monthly</Text>
          </GlassCard>
          <GlassCard className="flex-1 py-2 items-center">
            <Text className="text-sm font-semibold text-muted">All Time</Text>
          </GlassCard>
        </View>

        {/* Leaderboard List */}
        <View className="px-4 pb-8">
          <Text className="text-lg font-semibold text-foreground mb-3">Top Rankings</Text>
          <FlatList
            data={leaderboardData}
            renderItem={renderLeaderboardItem}
            keyExtractor={(item) => item.rank.toString()}
            scrollEnabled={false}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
