import { ScrollView, Text, View, Pressable } from "react-native";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { GlassCard } from "@/components/glass-card";
import { PremiumButton } from "@/components/premium-button";
import { useColors } from "@/hooks/use-colors";

interface Question {
  id: string;
  question: string;
  type: "multiple-choice" | "true-false" | "fill-blank";
  options?: string[];
  correctAnswer: string;
}

/**
 * Quiz Screen - Interactive quiz mode with instant feedback
 *
 * Features:\n * - Multiple choice, true/false, and fill-in-the-blank questions
 * - Instant feedback on answers
 * - Progress tracking
 * - Results summary
 */
export default function QuizScreen() {
  const colors = useColors();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);
  const [quizComplete, setQuizComplete] = useState(false);

  const questions: Question[] = [
    {
      id: "1",
      question: "What is the powerhouse of the cell?",
      type: "multiple-choice",
      options: ["Nucleus", "Mitochondria", "Ribosome", "Chloroplast"],
      correctAnswer: "Mitochondria",
    },
    {
      id: "2",
      question: "Photosynthesis occurs in plants.",
      type: "true-false",
      options: ["True", "False"],
      correctAnswer: "True",
    },
    {
      id: "3",
      question: "The process of DNA replication is called ___.",
      type: "fill-blank",
      options: ["Transcription", "Translation", "Replication", "Mutation"],
      correctAnswer: "Replication",
    },
  ];

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswer(answer);
    setShowFeedback(true);
    if (answer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowFeedback(false);
    } else {
      setQuizComplete(true);
    }
  };

  const handleRestartQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowFeedback(false);
    setScore(0);
    setQuizComplete(false);
  };

  if (quizComplete) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <ScreenContainer className="flex-1 bg-background items-center justify-center px-4">
        <GlassCard className="w-full p-8 items-center">
          <Text className="text-5xl font-bold text-primary mb-2">{percentage}%</Text>
          <Text className="text-2xl font-semibold text-foreground mb-1">Quiz Complete!</Text>
          <Text className="text-base text-muted text-center mb-6">
            You got {score} out of {questions.length} questions correct.
          </Text>

          <View className="w-full gap-3">
            <GlassCard className="p-4 items-center">
              <Text className="text-sm text-muted">Average Accuracy</Text>
              <Text className="text-3xl font-bold text-primary mt-1">{percentage}%</Text>
            </GlassCard>

            <GlassCard className="p-4 items-center">
              <Text className="text-sm text-muted">Weak Areas</Text>
              <Text className="text-base text-foreground mt-2">Cell Structure</Text>
              <Text className="text-xs text-muted mt-1">Review these concepts</Text>
            </GlassCard>
          </View>

          <View className="w-full gap-2 mt-6">
            <PremiumButton
              label="Retake Quiz"
              variant="primary"
              size="lg"
              onPress={handleRestartQuiz}
            />
            <PremiumButton
              label="Return to Home"
              variant="secondary"
              size="lg"
              onPress={() => console.log("Return Home")}
            />
          </View>
        </GlassCard>
      </ScreenContainer>
    );
  }

  const question = questions[currentQuestion];
  const isCorrect = selectedAnswer === question.correctAnswer;

  return (
    <ScreenContainer className="flex-1 bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1, padding: 16 }} showsVerticalScrollIndicator={false}>
        {/* Progress Bar */}
        <View className="mb-6">
          <View className="flex-row justify-between mb-2">
            <Text className="text-sm font-semibold text-foreground">
              Question {currentQuestion + 1} of {questions.length}
            </Text>
            <Text className="text-sm text-muted">{Math.round(((currentQuestion + 1) / questions.length) * 100)}%</Text>
          </View>
          <View className="h-2 bg-surface rounded-full overflow-hidden">
            <View
              className="h-full bg-gradient-accent"
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            />
          </View>
        </View>

        {/* Question */}
        <GlassCard className="p-6 mb-6">
          <Text className="text-lg font-semibold text-foreground leading-relaxed">{question.question}</Text>
        </GlassCard>

        {/* Answer Options */}
        <View className="gap-3 mb-6">
          {question.options?.map((option, index) => {
            const isSelected = selectedAnswer === option;
            const isCorrectOption = option === question.correctAnswer;
            let bgColor = "bg-surface";
            let borderColor = "border-border";

            if (showFeedback && isSelected) {
              bgColor = isCorrect ? "bg-success/20" : "bg-error/20";
              borderColor = isCorrect ? "border-success" : "border-error";
            } else if (showFeedback && isCorrectOption) {
              bgColor = "bg-success/20";
              borderColor = "border-success";
            }

            return (
              <Pressable
                key={index}
                onPress={() => !showFeedback && handleAnswerSelect(option)}
                disabled={showFeedback}
                className={`border-2 rounded-md p-4 flex-row items-center justify-between ${bgColor} ${borderColor}`}
                style={({ pressed }) => [{ opacity: pressed && !showFeedback ? 0.7 : 1 }]}
              >
                <Text className="flex-1 text-base font-medium text-foreground">{option}</Text>
                {showFeedback && isCorrectOption && (
                  <Text className="text-lg">✓</Text>
                )}
                {showFeedback && isSelected && !isCorrect && (
                  <Text className="text-lg">✗</Text>
                )}
              </Pressable>
            );
          })}
        </View>

        {/* Feedback Message */}
        {showFeedback && (
          <GlassCard
            className={`p-4 mb-6 ${isCorrect ? "bg-success/10" : "bg-error/10"}`}
          >
            <Text className={`text-base font-semibold ${isCorrect ? "text-success" : "text-error"}`}>
              {isCorrect ? "✓ Correct!" : "✗ Incorrect"}
            </Text>
            <Text className="text-sm text-foreground mt-2">
              {isCorrect
                ? "Great job! You got this one right."
                : "The correct answer is: " + question.correctAnswer}
            </Text>
          </GlassCard>
        )}

        {/* Next Button */}
        {showFeedback && (
          <PremiumButton
            label={currentQuestion === questions.length - 1 ? "See Results" : "Next Question"}
            variant="primary"
            size="lg"
            onPress={handleNextQuestion}
          />
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
