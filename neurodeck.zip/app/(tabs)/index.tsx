import { ScrollView, Text, View, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { GlassCard } from "@/components/glass-card";
import { PremiumButton } from "@/components/premium-button";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useTheme } from "@/lib/theme-context";

/**
 * Home Screen - NeuroDeck Premium Study Dashboard
 *
 * Features:
 * - Animated progress ring with XP tracking
 * - Quick stats grid (Streak, XP, Cards Mastered)
 * - Weekly activity mini-graph
 * - Motivational insights
 * - Action buttons for quick access
 * - Theme toggle (light/dark)
 */
export default function HomeScreen() {
  const colors = useColors();
  const { colorScheme, toggleTheme } = useTheme();

  // Mock data for demonstration
  const userStats = {
    xp: 2450,
    maxXp: 5000,
    streak: 12,
    cardsMastered: 187,
    studyHours: 24,
    accuracy: 87,
  };

  const weeklyData = [5, 8, 12, 7, 15, 10, 8]; // Study sessions per day

  return (
    <ScreenContainer className="flex-1 bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Header with Theme Toggle */}
        <View className="flex-row items-center justify-between px-4 py-4">
          <Text className="text-3xl font-bold text-foreground">NeuroDeck</Text>
          <Pressable
            onPress={toggleTheme}
            style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
            className="p-2"
          >
            <IconSymbol
              name={colorScheme === "dark" ? "sun.max.fill" : "moon.fill"}
              size={24}
              color={colors.primary}
            />
          </Pressable>
        </View>

        {/* Daily Progress Ring */}
        <View className="items-center py-6">
          <GlassCard className="w-40 h-40 items-center justify-center">
            <View className="items-center">
              <Text className="text-4xl font-bold text-primary">
                {Math.round((userStats.xp / userStats.maxXp) * 100)}%
              </Text>
              <Text className="text-sm text-muted mt-1">Today's Progress</Text>
              <Text className="text-xs text-muted mt-1">
                {userStats.xp} / {userStats.maxXp} XP
              </Text>
            </View>
          </GlassCard>
        </View>

        {/* Quick Stats Grid */}
        <View className="px-4 gap-3">
          <View className="flex-row gap-3">
            <GlassCard className="flex-1 p-4 items-center">
              <Text className="text-2xl font-bold text-primary">{userStats.streak}</Text>
              <Text className="text-xs text-muted mt-1">Day Streak</Text>
            </GlassCard>
            <GlassCard className="flex-1 p-4 items-center">
              <Text className="text-2xl font-bold text-primary">{userStats.cardsMastered}</Text>
              <Text className="text-xs text-muted mt-1">Cards Mastered</Text>
            </GlassCard>
            <GlassCard className="flex-1 p-4 items-center">
              <Text className="text-2xl font-bold text-primary">{userStats.accuracy}%</Text>
              <Text className="text-xs text-muted mt-1">Accuracy</Text>
            </GlassCard>
          </View>
        </View>

        {/* Weekly Activity */}
        <View className="px-4 py-6 gap-2">
          <Text className="text-lg font-semibold text-foreground">Weekly Activity</Text>
          <GlassCard className="p-4">
            <View className="flex-row items-end justify-between h-16 gap-1">
              {weeklyData.map((value, index) => (
                <View
                  key={index}
                  className="flex-1 bg-gradient-accent rounded-sm"
                  style={{
                    height: `${(value / 15) * 100}%`,
                    minHeight: 4,
                  }}
                />
              ))}
            </View>
            <View className="flex-row justify-between mt-2">
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, index) => (
                <Text key={index} className="text-xs text-muted">
                  {day}
                </Text>
              ))}
            </View>
          </GlassCard>
        </View>

        {/* Motivational Insight */}
        <View className="px-4 py-4">
          <GlassCard className="p-4 bg-gradient-accent/10 dark:bg-gradient-accent/5">
            <Text className="text-sm font-semibold text-primary mb-2">💡 Daily Insight</Text>
            <Text className="text-sm text-foreground leading-relaxed">
              You're on a 12-day streak! Keep it up—consistency is the key to mastering new concepts.
            </Text>
          </GlassCard>
        </View>

        {/* Action Buttons */}
        <View className="px-4 py-6 gap-3">
          <PremiumButton
            label="Start Quiz"
            variant="primary"
            size="lg"
            onPress={() => console.log("Start Quiz")}
          />
          <PremiumButton
            label="Review Deck"
            variant="secondary"
            size="lg"
            onPress={() => console.log("Review Deck")}
          />
          <PremiumButton
            label="Create Flashcard"
            variant="ghost"
            size="lg"
            onPress={() => console.log("Create Flashcard")}
          />
        </View>

        {/* Recent Activity */}
        <View className="px-4 pb-8">
          <Text className="text-lg font-semibold text-foreground mb-3">Recent Decks</Text>
          <GlassCard className="p-4 mb-3">
            <View className="flex-row items-center justify-between">
              <View className="flex-1">
                <Text className="text-base font-semibold text-foreground">Biology 101</Text>
                <Text className="text-xs text-muted mt-1">45 cards • 87% mastered</Text>
              </View>
              <Text className="text-sm text-primary font-semibold">→</Text>
            </View>
          </GlassCard>
          <GlassCard className="p-4 mb-3">
            <View className="flex-row items-center justify-between">
              <View className="flex-1">
                <Text className="text-base font-semibold text-foreground">Spanish Vocab</Text>
                <Text className="text-xs text-muted mt-1">120 cards • 62% mastered</Text>
              </View>
              <Text className="text-sm text-primary font-semibold">→</Text>
            </View>
          </GlassCard>
          <GlassCard className="p-4">
            <View className="flex-row items-center justify-between">
              <View className="flex-1">
                <Text className="text-base font-semibold text-foreground">Math Formulas</Text>
                <Text className="text-xs text-muted mt-1">78 cards • 91% mastered</Text>
              </View>
              <Text className="text-sm text-primary font-semibold">→</Text>
            </View>
          </GlassCard>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
