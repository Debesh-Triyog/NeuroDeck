# NeuroDeck - Mobile App Design System

## Design Philosophy

NeuroDeck is a **premium, venture-backed study app** that feels like a first-party iOS application. The design emphasizes elegance, sophistication, and delightful micro-interactions while maintaining accessibility and performance.

### Core Design Principles

- **Glassmorphism**: Frosted glass cards with subtle blur, transparency, and soft shadows
- **Neon Blue Accents**: Deep navy → indigo gradient base with electric neon blue highlights
- **Premium Typography**: Inter font family with breathable spacing and zero visual noise
- **60fps Animations**: Smooth, subtle transitions that enhance rather than distract
- **One-Handed Usage**: All interactive elements within thumb reach on mobile portrait (9:16)
- **Haptic Feedback**: Subtle vibrations for key interactions (button taps, toggles, achievements)

---

## Color Palette

### Light Theme
- **Background**: `#FFFFFF` (Pure white)
- **Surface**: `#F5F7FA` (Soft light gray)
- **Primary (Neon Blue)**: `#00D9FF` (Electric cyan)
- **Accent**: `#0066FF` (Deep blue)
- **Foreground (Text)**: `#0F1419` (Near black)
- **Muted (Secondary Text)**: `#6B7280` (Medium gray)
- **Border**: `#E5E7EB` (Light gray)
- **Success**: `#10B981` (Emerald)
- **Warning**: `#F59E0B` (Amber)
- **Error**: `#EF4444` (Red)

### Dark Theme (Premium)
- **Background**: `#0F1419` (Deep navy)
- **Surface**: `#1A1F2E` (Navy with slight purple tint)
- **Primary (Neon Blue)**: `#00D9FF` (Electric cyan - same across themes)
- **Accent**: `#0066FF` (Deep blue)
- **Foreground (Text)**: `#F3F4F6` (Off-white)
- **Muted (Secondary Text)**: `#9CA3AF` (Light gray)
- **Border**: `#334155` (Dark slate)
- **Success**: `#34D399` (Bright emerald)
- **Warning**: `#FBBF24` (Bright amber)
- **Error**: `#F87171` (Bright red)

### Gradients
- **Primary Gradient**: `linear-gradient(135deg, #001F3F 0%, #0F1419 50%, #1A1F2E 100%)` (Deep navy → indigo)
- **Accent Gradient**: `linear-gradient(135deg, #00D9FF 0%, #0066FF 100%)` (Neon blue → deep blue)
- **Card Gradient (Dark)**: `linear-gradient(135deg, rgba(26, 31, 46, 0.8) 0%, rgba(15, 20, 25, 0.6) 100%)`

---

## Screen List

### 1. **Onboarding & Auth**
- **Splash Screen**: App logo, brand name, loading indicator
- **Welcome Screen**: Hero copy, "Get Started" button
- **Goal Selection**: Choose study goal (Exam prep, School, Skill building)
- **Subject Selection**: Pick subjects of interest
- **Daily Goal Setup**: Set daily study target (minutes or cards)
- **Email Capture Popup**: Minimal glassmorphic modal for email signup
- **First Deck Creation**: Quick deck creation to onboard in <60 seconds

### 2. **Home Screen**
- **Header**: App title, theme toggle button (sun/moon icon)
- **Daily Progress Ring**: Animated circular progress indicator (XP/minutes)
- **Quick Stats**: Streak count, total XP, cards mastered (3-column grid)
- **Weekly Mini-Graph**: 7-day study activity sparkline
- **Motivational Insight**: Personalized daily message
- **Action Buttons**: "Start Quiz", "Review Deck", "Create Flashcard"
- **Recent Activity**: Last 3 decks or recent study sessions

### 3. **Decks Screen**
- **Header**: "My Decks" title, "+" button to create new deck
- **Deck Cards**: Grid or list view with:
  - Deck name and subject
  - Card count and mastery percentage
  - Last studied date
  - Quick action buttons (Study, Quiz, Delete)
- **Empty State**: Illustration + "Create your first deck" prompt
- **Filter/Sort**: Options to filter by subject or sort by recent

### 4. **Quiz Screen**
- **Quiz Header**: Quiz title, progress bar (current question / total)
- **Question Display**: Large, readable question text
- **Answer Options**: Multiple choice, true/false, or fill-in-the-blank
- **Submit Button**: Prominent CTA with haptic feedback
- **Feedback**: Instant visual feedback (correct/incorrect)
- **Results Screen**: Score, accuracy, weak areas, option to retake

### 5. **Leaderboard Screen**
- **Rank Badge**: User's current rank (Bronze → Grand Scholar)
- **User Stats**: Name, XP, rank, streak count
- **Leaderboard Table**: Top 10-50 users with:
  - Rank number
  - User avatar/initial
  - User name
  - XP points
  - Rank badge
- **Time Filter**: Toggle between weekly/monthly/all-time
- **Friends View**: Option to see only friends' rankings

### 6. **Profile Screen**
- **User Header**: Avatar, name, rank badge, XP level
- **Stats Grid**: 
  - Total study hours
  - Cards mastered
  - Accuracy percentage
  - Current streak
  - Achievements unlocked
- **Settings Section**:
  - Theme toggle (light/dark)
  - Notification preferences
  - Privacy settings
  - About & Help
- **Logout Button**: Bottom of screen

### 7. **AI Flashcard Creation**
- **Input Method Selector**: Paste notes, Upload PDF, Scan text, Type topic
- **Content Input**: Text area or file upload
- **Generate Button**: "Generate Flashcards" with loading state
- **Preview**: Show generated flashcards before saving
- **Save Action**: Add to existing deck or create new deck

### 8. **AI Summary System**
- **Summary Type Selector**: Quick (1-min), Standard, Deep Concept Breakdown
- **Generate Button**: Loading state with progress indicator
- **Summary Display**: Bullet points, key concepts, definitions
- **Action Buttons**: "Convert to Flashcards", "Generate Quiz"

### 9. **Focus Mode / Pomodoro**
- **Timer Display**: Large, easy-to-read countdown
- **Study/Break Cycle**: Visual indicator of current phase
- **Pause/Resume**: Simple controls
- **Session Summary**: Time studied, cards reviewed, XP earned

### 10. **Flashcard Study**
- **Card Display**: Large, centered card with question/answer
- **Flip Animation**: Smooth 3D flip on tap
- **Swipe Gestures**:
  - Swipe right → Mastered (green)
  - Swipe left → Review again (red)
- **Long Press**: Show deep explanation
- **Bookmark**: Star icon to save for later
- **Progress**: Card counter (current / total)

---

## Key User Flows

### Flow 1: Onboarding (First Launch)
1. User opens app → Splash screen
2. Welcome screen with "Get Started" button
3. Select study goal (Exam prep / School / Skill building)
4. Select subjects of interest
5. Set daily study goal (e.g., 30 minutes)
6. Email capture popup (optional but encouraged)
7. Create first deck instantly
8. See first AI-generated flashcards
9. Land on Home screen

### Flow 2: Create & Study Flashcards
1. User taps "+" on Decks screen
2. Choose input method (paste notes, upload PDF, type topic)
3. Paste content or type topic
4. Tap "Generate Flashcards"
5. AI generates flashcards (show loading state)
6. Preview generated cards
7. Tap "Save to Deck"
8. Return to Decks screen
9. User taps deck → Study screen
10. Swipe right to master, left to review

### Flow 3: Take a Quiz
1. User taps "Start Quiz" on Home or selects quiz from Decks
2. Quiz header shows progress (1/10)
3. Question displays with answer options
4. User selects answer → Instant feedback (correct/incorrect)
5. Next button appears
6. After final question → Results screen
7. Show score, accuracy, weak areas
8. Option to retake or return to Home

### Flow 4: Check Leaderboard
1. User taps "Leaderboard" tab
2. See their rank and XP
3. Browse top 50 users
4. Toggle between weekly/monthly/all-time
5. View friends' rankings (if available)
6. Return to other screens

### Flow 5: Toggle Theme
1. User taps sun/moon icon on Home header
2. App transitions smoothly to light/dark theme
3. All screens update instantly
4. Preference saved locally

---

## Layout Specifications

### Mobile Portrait (9:16 aspect ratio)

**Safe Area Padding**: 16px horizontal, 12px top/bottom

**Tab Bar**: 
- Height: 56px + safe area bottom
- 5 tabs: Home, Decks, Quiz, Leaderboard, Profile
- Icons + labels
- Background: Surface color with 1px top border

**Card Spacing**: 12px between cards, 16px from edges

**Typography**:
- **Hero Title**: 32px, bold, foreground color
- **Section Title**: 20px, semibold, foreground color
- **Body Text**: 16px, regular, foreground color
- **Small Text**: 14px, regular, muted color
- **Caption**: 12px, regular, muted color

**Button Sizes**:
- **Primary Button**: 48px height, 100% width (max 320px)
- **Secondary Button**: 40px height
- **Icon Button**: 44px × 44px (minimum touch target)

**Border Radius**:
- **Cards**: 16px
- **Buttons**: 12px
- **Input Fields**: 12px
- **Modals**: 20px (top corners)

---

## Component Specifications

### Glassmorphic Card
- Background: `rgba(255, 255, 255, 0.1)` (light) or `rgba(26, 31, 46, 0.5)` (dark)
- Backdrop blur: 10px
- Border: 1px solid `rgba(255, 255, 255, 0.2)` (light) or `rgba(255, 255, 255, 0.1)` (dark)
- Shadow: `0 8px 32px rgba(0, 0, 0, 0.1)` (light) or `0 8px 32px rgba(0, 0, 0, 0.3)` (dark)
- Padding: 16px
- Border radius: 16px

### Neon Blue Button
- Background: `#00D9FF` (light theme) or gradient `#00D9FF → #0066FF` (dark theme)
- Text: `#0F1419` (light) or `#FFFFFF` (dark)
- Height: 48px
- Border radius: 12px
- Press state: Scale 0.97, opacity 0.8
- Haptic: Light impact on press

### Progress Ring
- Outer circle: 120px diameter
- Inner text: XP count, large bold number
- Stroke width: 8px
- Colors: Gradient from neon blue to deep blue
- Animation: Smooth fill on mount (500ms)

### Flashcard
- Aspect ratio: 3:4 (portrait)
- Background: Glassmorphic gradient
- Min height: 280px
- Flip animation: 300ms, 3D perspective
- Shadow: Elevated (0 12px 48px rgba)

---

## Animations & Transitions

### Micro-interactions
- **Button Press**: Scale 0.97 (80ms), haptic feedback
- **Card Flip**: 3D rotation (300ms), easing ease-in-out
- **Progress Ring Fill**: Smooth animation (500ms), easing ease-out
- **Tab Switch**: Fade + slide (200ms)
- **Modal Appear**: Scale + fade (250ms), easing ease-out
- **Swipe Feedback**: Color change + slight scale (150ms)

### Page Transitions
- **Screen Enter**: Fade in (150ms)
- **Screen Exit**: Fade out (100ms)
- **Modal Enter**: Scale from center (250ms)
- **Modal Exit**: Scale to center (150ms)

### Loading States
- **Skeleton Loader**: Pulsing opacity (1s loop)
- **Spinner**: Rotating neon blue circle (1s loop)
- **Progress Bar**: Smooth fill animation

---

## Accessibility

- **Touch Targets**: Minimum 44px × 44px
- **Color Contrast**: WCAG AA compliant (4.5:1 for text)
- **Typography**: Clear hierarchy with size and weight
- **Keyboard Navigation**: All interactive elements accessible
- **Screen Reader**: Semantic HTML, descriptive labels
- **Haptic Feedback**: Optional toggle in settings

---

## Responsive Breakpoints

- **Mobile** (< 640px): Single column, bottom tab bar
- **Tablet** (641px - 1024px): Two-column layout, collapsible sidebar
- **Desktop** (> 1024px): Fixed sidebar, multi-column analytics

---

## Premium Feel Checklist

- ✅ Glassmorphism cards with blur and transparency
- ✅ Neon blue accents on dark navy background
- ✅ Smooth 60fps animations and transitions
- ✅ Premium Inter typography with breathable spacing
- ✅ Subtle haptic feedback on interactions
- ✅ Consistent branding across all screens
- ✅ Light and dark theme with seamless toggle
- ✅ Zero visual clutter, maximum clarity
- ✅ Responsive design for all devices
- ✅ Polished loading and empty states
